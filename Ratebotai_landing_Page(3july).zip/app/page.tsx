import RateBotLanding from "./components/landing-page"

export default function Page() {
  return <RateBotLanding />
}
